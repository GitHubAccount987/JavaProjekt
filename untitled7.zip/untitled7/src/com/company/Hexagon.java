package com.company;

public class Hexagon extends Polygon {

    private double apothem;

    public Hexagon(double length) {

        super(6, length);

        this.apothem = length/2/Math.tan(Math.toRadians(30));

    }

    double getApothem() { return apothem; }

    void setApothem(double apothem) { this.apothem = apothem; }

    @Override
    public double calculateArea() { return sides*apothem*sideLength/2; }

}