package com.company;

/*public*/ class Octagon extends Polygon {

    private double apothem;

    public Octagon(double length) {

        super(8, length);

        this.apothem = length/2/Math.tan(Math.PI/8d);

    }

    double getApothem() { return apothem; }

    void setApothem(double apothem) { this.apothem = apothem; }

    @Override
    public double calculateArea() { return sides*apothem*sideLength/2; }

}