package com.company;

/*public*/ class Decagon extends Polygon {

    private double apothem;

    public Decagon(double length) {

        super(10, length);

        this.apothem = length/2/Math.tan(Math.toRadians(18));

    }

    double getApothem() { return apothem; }

    void setApothem(double apothem) { this.apothem = apothem; }

    @Override
    public double calculateArea() { return sides*apothem*sideLength/2; }

}