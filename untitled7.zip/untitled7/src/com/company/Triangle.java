package com.company;

public class Triangle extends Polygon {

    public Triangle(double length) { super(3, length); }

    @Override
    public double calculateArea() { return Math.sqrt(3)/4*(sideLength*sideLength); }
}
