package com.company;

public class Square extends Polygon {

    public Square(double length) { super(4, length); }

    @Override
    public double calculateArea() { return sideLength*sideLength; }

}
