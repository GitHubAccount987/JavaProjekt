package com.company;

public class Nonagon extends Polygon {

    private double apothem;

    public Nonagon(double length) {

        super(9, length);

        this.apothem = length/2/Math.tan(Math.toRadians(20));

    }

    double getApothem() { return apothem; }

    void setApothem(double apothem) { this.apothem = apothem; }

    @Override
    public double calculateArea() { return sides*apothem*sideLength/2; }

}