package com.company;

public class Pentagon extends Polygon {

    double apothem;

    public Pentagon(double length) {

        super(5, length);

        this.apothem = length/2/Math.tan(Math.toRadians(36));

    }

    double getApothem() { return apothem; }

    void setApothem(double apothem) { this.apothem = apothem; }

    @Override
    public double calculateArea() { return sides*apothem*sideLength/2; }

}