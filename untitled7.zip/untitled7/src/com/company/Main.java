package com.company;

import java.util.Scanner;

abstract class Polygon {

    // Data members

    protected int sides;
    protected double sideLength;

    // Constructor

    public Polygon(int sides, double sideLength) {
        if (sides <= 2) throw new IllegalArgumentException("Number of sides must be greater than 1");
        this.sides = sides;
        this.sideLength = sideLength;
    }

    // Getters

    int getSides() {
        return sides;
    }

    // Abstract methods

    public abstract double calculateArea();

}

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in, "Windows-1250");

        Triangle triangle;

        Square square;

        Pentagon pentagon;

        Hexagon hexagon;

        Heptagon heptagon;

        Octagon octagon;

        Nonagon nonagon;

        Decagon decagon;

        try {

            System.out.print("Triangle length: ");

            int length = scanner.nextInt();

            triangle = new Triangle(length);

            System.out.print("Square length  : ");

            length = scanner.nextInt();

            square = new Square(length);

            System.out.print("Pentagon length: ");

            length = scanner.nextInt();

            pentagon = new Pentagon(length);

            System.out.print("Hexagon length : ");

            length = scanner.nextInt();

            hexagon = new Hexagon(length);

            System.out.print("Heptagon length: ");

            length = scanner.nextInt();

            heptagon = new Heptagon(length);

            System.out.print("Octagon length : ");

            length = scanner.nextInt();

            octagon = new Octagon(length);

            System.out.print("Nonagon length : ");

            length = scanner.nextInt();

            nonagon = new Nonagon(length);

            System.out.print("Decagon length : ");

            length = scanner.nextInt();

            decagon = new Decagon(length);

            System.out.println("\n--------------------");

            System.out.println("Triangle: \nArea    : " + triangle.calculateArea() + "\nSides   : " + triangle.getSides() + "\n--------------------");
            System.out.println("Square  : \nArea    : " + square.calculateArea() + "\nSides   : " + square.getSides() + "\n--------------------");
            System.out.println("Pentagon: \nArea    : " + pentagon.calculateArea() + "\nSides   : " + pentagon.getSides() + "\n--------------------");
            System.out.println("Hexagon : \nArea    : " + hexagon.calculateArea() + "\nSides   : " + hexagon.getSides() + "\n--------------------");
            System.out.println("Heptagon: \nArea    : " + heptagon.calculateArea() + "\nSides   : " + heptagon.getSides() + "\n--------------------");
            System.out.println("Octagon : \nArea    : " + octagon.calculateArea() + "\nSides   : " + octagon.getSides() + "\n--------------------");
            System.out.println("Nonagon : \nArea    : " + nonagon.calculateArea() + "\nSides   : " + nonagon.getSides() + "\n--------------------");
            System.out.println("Decagon : \nArea    : " + decagon.calculateArea() + "\nSides   : " + decagon.getSides() + "\n--------------------");

        } catch (IllegalArgumentException e) {

            System.out.println("An exception has been thrown: " + e.getMessage());

        }
    }
}
