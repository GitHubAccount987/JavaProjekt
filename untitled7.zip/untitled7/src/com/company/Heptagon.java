package com.company;

/*public*/ class Heptagon extends Polygon {

    private double apothem;

    public Heptagon(double length) {

        super(7, length);

        this.apothem = length/2/Math.tan(Math.toRadians(360/14d));

    }

    double getApothem() { return apothem; }

    void setApothem(double apothem) { this.apothem = apothem; }

    @Override
    public double calculateArea() { return sides*apothem*sideLength/2; }

}